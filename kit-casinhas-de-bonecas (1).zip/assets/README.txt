COLOQUE SEUS ARQUIVOS PNG NESTA PASTA.

Para que o site exiba as imagens corretamente, os arquivos devem ter estes nomes exatos:

- hero_showcase.png (Imagem principal do topo)
- grid_1.png, grid_2.png, grid_3.png, grid_4.png (Fotos da galeria)
- ambiente_1.png, ambiente_2.png, ambiente_3.png (Carrossel de Ambientes)
- boneca_1.png, boneca_2.png, boneca_3.png (Carrossel de Bonecas)
- especial_1.png, especial_2.png, especial_3.png (Carrossel Especial)
- bonus_sereia.png (Imagem do bônus sereia)
- bonus_maquiagem.png (Imagem do bônus maquiagem)