
/**
 * CENTRAL DE ATIVOS (IMAGENS)
 * 
 * Para adicionar suas imagens, basta colocar os arquivos PNG na pasta 'assets'
 * com os nomes definidos abaixo.
 */

export const ASSETS = {
  hero: {
    showcase: "./assets/hero_showcase.png",
  },
  productGrid: [
    "./assets/grid_1.png",
    "./assets/grid_2.png",
    "./assets/grid_3.png",
    "./assets/grid_4.png"
  ],
  collections: {
    ambientes: [
      "./assets/ambiente_1.png",
      "./assets/ambiente_2.png",
      "./assets/ambiente_3.png"
    ],
    bonecas: [
      "./assets/boneca_1.png",
      "./assets/boneca_2.png",
      "./assets/boneca_3.png"
    ],
    especial: [
      "./assets/especial_1.png",
      "./assets/especial_2.png",
      "./assets/especial_3.png"
    ]
  },
  bonus: {
    sereia: "./assets/bonus_sereia.png",
    maquiagem: "./assets/bonus_maquiagem.png"
  }
};
