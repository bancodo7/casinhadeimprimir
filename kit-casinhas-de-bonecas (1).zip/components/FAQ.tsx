
import React, { useState, useRef } from 'react';
import { ChevronDown } from 'lucide-react';

const FAQItem: React.FC<{ question: string, answer: string }> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  return (
    <div className="bg-white rounded-2xl mb-3 overflow-hidden shadow-sm transition-all duration-300">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-5 py-4 flex justify-between items-center text-left hover:bg-gray-50 transition-colors"
      >
        <span className="text-purple-main font-bold text-xs pr-4">{question}</span>
        <ChevronDown 
          size={16} 
          className={`text-purple-main transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} 
        />
      </button>
      
      <div 
        ref={contentRef}
        style={{ 
          maxHeight: isOpen ? `${contentRef.current?.scrollHeight}px` : '0px',
          opacity: isOpen ? 1 : 0
        }}
        className="transition-all duration-300 ease-in-out"
      >
        <div className="px-5 pb-5 text-[11px] text-gray-500 leading-relaxed pt-2 border-t border-gray-50">
          {answer}
        </div>
      </div>
    </div>
  );
};

const FAQ: React.FC = () => {
  const faqs = [
    {
      question: "O material é digital ou físico?",
      answer: "É 100% digital. Você recebe os arquivos em PDF no seu email logo após a confirmação do pagamento. Assim você não paga frete e pode imprimir quantas vezes quiser!"
    },
    {
      question: "Preciso de uma impressora especial?",
      answer: "Não! Você pode imprimir em qualquer impressora doméstica comum. Recomendamos papel com gramatura 180g (mais durinho) para as casinhas ficarem mais firmes, mas funciona até em papel sulfite comum."
    },
    {
      question: "Como acesso o vídeo passo a passo?",
      answer: "Junto com os arquivos PDF, você receberá um link exclusivo para assistir ao vídeo onde mostramos exatamente como montar cada peça."
    },
    {
      question: "Para qual idade é recomendado?",
      answer: "Crianças a partir de 4 anos adoram brincar. Para o recorte e montagem, recomendamos supervisão de um adulto para crianças menores de 7 anos. É uma ótima atividade em família!"
    }
  ];

  return (
    <section className="px-6 py-12">
      <h2 className="text-center text-white text-2xl font-black mb-8">Perguntas Frequentes</h2>
      <div>
        {faqs.map((faq, i) => (
          <FAQItem key={i} question={faq.question} answer={faq.answer} />
        ))}
      </div>
    </section>
  );
};

export default FAQ;
