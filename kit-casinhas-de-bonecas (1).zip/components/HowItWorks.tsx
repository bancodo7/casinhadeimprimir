
import React from 'react';
import { Download, Printer, Scissors, Palette } from 'lucide-react';

const Step: React.FC<{ icon: React.ReactNode, title: string, desc: string, number: string }> = ({ icon, title, desc, number }) => (
  <div className="bg-white rounded-2xl p-6 text-center shadow-md relative mt-8 flex flex-col items-center">
    <div className="text-purple-main mb-3">
      {icon}
    </div>
    <h3 className="text-purple-main font-bold text-lg mb-1">{number}. {title}</h3>
    <p className="text-gray-500 text-xs leading-relaxed">{desc}</p>
  </div>
);

const HowItWorks: React.FC = () => {
  return (
    <section className="px-6 py-12 bg-white/5">
      <h2 className="text-center text-white text-2xl font-black mb-4">Como Funciona?</h2>
      
      <div className="space-y-4">
        <Step 
          number="1"
          icon={<Download size={32} />} 
          title="Baixe o PDF" 
          desc="Receba o arquivo digital imediatamente no seu email." 
        />
        <Step 
          number="2"
          icon={<Printer size={32} />} 
          title="Imprima" 
          desc="Use papel comum ou cartolina em qualquer impressora." 
        />
        <Step 
          number="3"
          icon={<Scissors size={32} />} 
          title="Recorte & Cole" 
          desc="Siga as linhas pontilhadas. É super relaxante!" 
        />
        <Step 
          number="4"
          icon={<Palette size={32} />} 
          title="Brinque!" 
          desc="Crie histórias mágicas e decore do seu jeito." 
        />
      </div>
    </section>
  );
};

export default HowItWorks;
