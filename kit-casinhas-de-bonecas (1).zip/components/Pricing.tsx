
import React from 'react';
import { ShieldCheck } from 'lucide-react';

const Pricing: React.FC = () => {
  const handlePurchase = () => {
    window.location.href = "https://pay.lowify.com.br/checkout?product_id=tgLMD0";
  };

  return (
    <section id="pricing-section" className="px-6 py-12 scroll-mt-10">
      {/* Outer Card with subtle top border gradient */}
      <div className="bg-white rounded-[48px] p-8 shadow-2xl relative border-t-4 border-t-transparent overflow-hidden" style={{ borderImage: 'linear-gradient(to right, #ec4899, #8b5cf6, #06b6d4) 1' }}>
        
        <h2 className="text-center text-[#9333ea] text-2xl font-black mb-1">Oferta Especial</h2>
        <p className="text-center text-gray-500 text-sm mb-10">Tudo isso por um preço simbólico!</p>

        {/* Dashed List Box */}
        <div className="bg-[#f8fafc] rounded-3xl border-2 border-dashed border-[#e2e8f0] p-6 mb-10">
          <div className="space-y-4">
            <div className="flex justify-between text-xs font-medium text-gray-500 uppercase tracking-wide">
              <span>Kit Completo Casinhas</span>
              <span className="font-bold">R$ 47,00</span>
            </div>
            <div className="flex justify-between text-xs font-medium text-gray-500 uppercase tracking-wide">
              <span>Bônus Sereia</span>
              <span className="font-bold">R$ 19,90</span>
            </div>
            <div className="flex justify-between text-xs font-medium text-gray-500 uppercase tracking-wide">
              <span>Bônus Maquiagem</span>
              <span className="font-bold">R$ 14,90</span>
            </div>
            
            <div className="h-[1px] bg-gray-200 w-full mt-2"></div>
            
            <div className="flex justify-between items-center font-bold text-base text-[#9333ea] pt-2">
              <span>Valor Total:</span>
              <span className="relative">
                R$ 81,80
                <span className="absolute left-0 top-1/2 w-full h-[2px] bg-[#ec4899] rotate-[-5deg]"></span>
              </span>
            </div>
          </div>
        </div>

        {/* Giant Price Section */}
        <div className="text-center mb-10">
          <span className="text-xs font-bold text-[#9333ea] uppercase tracking-[0.2em]">HOJE POR APENAS:</span>
          <div className="flex items-baseline justify-center gap-1 mt-2">
            <span className="text-2xl font-bold text-gray-400">R$</span>
            <span className="text-7xl font-black text-[#9333ea] tracking-tighter">19,90</span>
          </div>
          <p className="text-[11px] text-gray-400 mt-4 font-medium uppercase tracking-wider">Pagamento único. Acesso vitalício.</p>
        </div>

        {/* Purchase Button */}
        <button 
          onClick={handlePurchase}
          className="bg-[#4ade80] hover:bg-[#22c55e] transition-all transform active:scale-95 text-white font-black py-5 px-6 rounded-[32px] shadow-[0_10px_20px_rgba(74,222,128,0.3)] flex items-center justify-center gap-2 w-full text-xl uppercase tracking-widest mb-10 animate-pulse-soft"
        >
          COMPRAR AGORA
        </button>

        {/* Guarantee Box */}
        <div className="bg-[#f8fafc] rounded-2xl py-3 px-4 flex items-center justify-center gap-3">
          <ShieldCheck size={20} className="text-[#22c55e]" />
          <span className="text-[10px] font-semibold text-gray-500 leading-tight text-center">
            Garantia de 7 Dias ou seu dinheiro de volta
          </span>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
