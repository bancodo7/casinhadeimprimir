
import React from 'react';
import { ASSETS } from '../constants/images';

const ProductGrid: React.FC = () => {
  return (
    <section className="px-6 py-6 relative">
      <div className="grid grid-cols-2 gap-3 bg-white/10 p-4 rounded-3xl border border-white/20">
        {ASSETS.productGrid.map((img, i) => (
          <div key={i} className="aspect-square rounded-2xl overflow-hidden shadow-inner">
            <img src={img} alt={`Preview ${i + 1}`} className="w-full h-full object-cover" />
          </div>
        ))}
      </div>
      
      {/* Price Bubble */}
      <div className="absolute top-0 right-4 bg-white text-purple-main w-24 h-24 rounded-full flex flex-col items-center justify-center shadow-2xl border-4 border-green-400 rotate-12 scale-110">
        <span className="text-[10px] font-bold uppercase leading-none">Oferta</span>
        <span className="text-lg font-black leading-none">R$19,90</span>
      </div>
    </section>
  );
};

export default ProductGrid;
