
import React, { useState, useEffect } from 'react';

const Header: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState({
    hours: 4,
    minutes: 58,
    seconds: 32
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        let { hours, minutes, seconds } = prev;
        if (seconds > 0) seconds--;
        else {
          seconds = 59;
          if (minutes > 0) minutes--;
          else {
            minutes = 59;
            if (hours > 0) hours--;
          }
        }
        return { hours, minutes, seconds };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const format = (num: number) => num.toString().padStart(2, '0');

  return (
    <header className="bg-white/10 backdrop-blur-sm px-4 py-2 flex justify-between items-center text-white text-[10px] uppercase font-bold tracking-wider">
      <div className="flex flex-col">
        <span>Oferta de Lançamento:</span>
        <span className="text-pink-400">Últimas Vagas!</span>
      </div>
      <div className="text-lg font-mono tracking-tighter">
        {format(timeLeft.hours)}:{format(timeLeft.minutes)}:{format(timeLeft.seconds)}
      </div>
    </header>
  );
};

export default Header;
