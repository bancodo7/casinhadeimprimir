
import React, { useState, useEffect } from 'react';
import { ASSETS } from '../constants/images';

const CollectionItem: React.FC<{ title: string, images: string[], delay: number }> = ({ title, images, delay }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    // Offset the start based on the delay to avoid synchronization
    const timeoutId = setTimeout(() => {
      const intervalId = setInterval(() => {
        setCurrentIndex((prev) => (prev + 1) % images.length);
      }, 3000); // Change every 3 seconds
      
      return () => clearInterval(intervalId);
    }, delay);

    return () => clearTimeout(timeoutId);
  }, [images.length, delay]);

  return (
    <div className="bg-white rounded-[40px] p-5 shadow-2xl mb-8 flex flex-col items-center border-4 border-white/50">
      <h3 className="text-purple-main font-black text-center mb-5 text-base uppercase tracking-widest">{title}</h3>
      <div className="w-full h-56 rounded-[32px] overflow-hidden relative shadow-inner group">
        <div 
          className="flex transition-transform duration-1000 ease-in-out h-full"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {images.map((img, i) => (
            <div key={i} className="min-w-full h-full flex-shrink-0">
              <img src={img} alt={`${title} ${i + 1}`} className="w-full h-full object-cover" />
            </div>
          ))}
        </div>
        
        {/* Carousel Indicators */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
          {images.map((_, i) => (
            <div 
              key={i} 
              className={`h-1.5 rounded-full transition-all duration-300 ${currentIndex === i ? 'w-6 bg-white' : 'w-1.5 bg-white/40'}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

const AccessContent: React.FC = () => {
  return (
    <section className="px-6 py-12">
      <h2 className="text-center text-white text-[22px] font-black mb-10 leading-tight">
        Aqui está tudo o que <br/> você terá acesso:
      </h2>
      
      <CollectionItem 
        title="Coleção Ambientes" 
        images={ASSETS.collections.ambientes} 
        delay={0}
      />
      <CollectionItem 
        title="Coleção Bonecas & Acessórios" 
        images={ASSETS.collections.bonecas} 
        delay={1000} // Starts 1 second later
      />
      <CollectionItem 
        title="Coleção Especial" 
        images={ASSETS.collections.especial} 
        delay={2000} // Starts 2 seconds later
      />
    </section>
  );
};

export default AccessContent;
