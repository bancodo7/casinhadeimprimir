
import React from 'react';
import { Star, ArrowRight } from 'lucide-react';
import { ASSETS } from '../constants/images';

const Hero: React.FC = () => {
  const benefits = [
    "Estimula criatividade e imaginação",
    "Fácil de imprimir, recortar e colar",
    "Vídeo passo a passo incluso",
    "Atividade divertida longe das telas"
  ];

  const scrollToPricing = () => {
    document.getElementById('pricing-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="px-6 py-12 text-center text-white flex flex-col items-center bg-hex-pattern relative overflow-hidden">
      {/* Badge matching reference */}
      <div className="bg-[#fbcfe8] text-[#7c3aed] text-xs font-bold px-5 py-2.5 rounded-full mb-8 flex items-center gap-2 shadow-lg transform -rotate-1">
        <span className="text-sm">✨</span>
        <span className="uppercase tracking-tight">Tendência para 2026</span>
      </div>
      
      {/* Headline matching reference */}
      <h1 className="text-[38px] font-black leading-[1.1] mb-8 text-shadow-custom max-w-[320px]">
        Kit Casinhas de Bonecas <span className="text-[#fbcfe8]">Para Imprimir</span>
      </h1>
      
      {/* Subtitle matching reference */}
      <p className="text-[17px] font-medium text-white/90 mb-10 max-w-[310px] mx-auto leading-relaxed">
        Casinhas em PDF prontas para montar em casa. Diversão garantida, visual moderno e fácil de fazer!
      </p>

      {/* Main Product Image Container */}
      <div className="w-full max-w-[360px] mb-10 rounded-[32px] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.3)] border-4 border-white/30 bg-white p-1">
        <img 
          src={ASSETS.hero.showcase} 
          alt="Demonstração do Kit de Casinhas" 
          className="w-full h-auto rounded-[28px] object-cover"
        />
      </div>

      {/* Benefits List */}
      <ul className="space-y-4 mb-10 text-left w-full max-w-[280px]">
        {benefits.map((benefit, i) => (
          <li key={i} className="flex items-center gap-4 text-[15px] font-semibold tracking-tight">
            <div className="bg-[#e11d48] rounded-full p-1.5 shadow-md">
              <Star size={14} fill="white" stroke="white" />
            </div>
            {benefit}
          </li>
        ))}
      </ul>

      {/* Primary CTA */}
      <button 
        onClick={scrollToPricing}
        className="bg-[#e11d48] hover:bg-[#be123c] transition-all transform hover:scale-105 active:scale-95 text-white font-black py-5 px-8 rounded-full shadow-[0_10px_20px_rgba(225,29,72,0.4)] flex items-center justify-center gap-3 w-full max-w-[320px] text-lg uppercase tracking-wider mb-3"
      >
        EU QUERO AGORA!
        <ArrowRight size={22} />
      </button>
      <span className="text-[11px] text-white/60 font-medium italic">* Acesso imediato após confirmação</span>
    </section>
  );
};

export default Hero;
