
import React from 'react';
import { ASSETS } from '../constants/images';

const BonusItem: React.FC<{ title: string, desc: string, price: string, image: string }> = ({ title, desc, price, image }) => (
  <div className="bg-white/10 p-4 rounded-3xl flex items-center gap-4 border border-white/20 mb-4 relative overflow-hidden">
    <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0 bg-white">
        <img src={image} alt={title} className="w-full h-full object-cover" />
    </div>
    <div className="flex flex-col">
      <div className="flex items-center gap-2 mb-1">
        <h4 className="text-white font-bold text-xs">{title}</h4>
        <span className="bg-green-500 text-white text-[8px] font-black px-1.5 py-0.5 rounded">GRÁTIS</span>
      </div>
      <p className="text-[10px] text-gray-300 mb-1 leading-tight">{desc}</p>
      <div className="text-[10px]">
        <span className="text-gray-400 line-through">Vendido por {price}</span>
        <div className="text-white font-bold">Hoje: R$ 0,00</div>
      </div>
    </div>
  </div>
);

const Bonus: React.FC = () => {
  return (
    <section className="px-6 py-12">
      <h2 className="text-center text-white text-2xl font-black mb-8">Bônus Exclusivos Para Hoje!</h2>
      
      <BonusItem 
        title="Boneca Sereia Edição Especial"
        desc="Um modelo exclusivo com acessórios de fundo do mar."
        price="R$ 19,90"
        image={ASSETS.bonus.sereia}
      />
      <BonusItem 
        title="Kit Maquiagem de Papel"
        desc="Pequenos itens para suas bonecas ficarem ainda mais lindas."
        price="R$ 14,90"
        image={ASSETS.bonus.maquiagem}
      />
    </section>
  );
};

export default Bonus;
