
import React from 'react';

const Footer: React.FC = () => {
  const scrollToPricing = () => {
    document.getElementById('pricing-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="px-6 py-12 bg-white/10 text-center">
      <h2 className="text-white text-2xl font-black mb-6">Pronto para começar a diversão?</h2>
      
      <button 
        onClick={scrollToPricing}
        className="bg-pink-main hover:bg-pink-700 transition-colors text-white font-black py-5 px-8 rounded-full shadow-lg w-full uppercase tracking-wider mb-8 text-sm"
      >
        SIM! EU QUERO AS CASINHAS
      </button>

      <p className="text-[9px] text-gray-300 mb-4">
        Copyright © 2024 Kit Casinhas de Boneca.
      </p>

      <p className="text-[8px] text-gray-400 leading-relaxed px-4">
        Este site não é afiliado ao Facebook ou a qualquer entidade do Facebook. Depois que você sair do Facebook, a responsabilidade não é deles e sim do nosso site. Fazemos todos os esforços para indicar claramente e mostrar todos os resultados do produto.
      </p>
    </footer>
  );
};

export default Footer;
